package com.mysite.kimdogyeomboard.answer;

import java.time.LocalDateTime;

import com.mysite.kimdogyeomboard.member.Member;
import com.mysite.kimdogyeomboard.question.Question;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
public class Answer {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@Column(columnDefinition = "TEXT")
	private String content;

	private boolean hidden;

	private LocalDateTime createDate;

	@ManyToOne
	private Member author;

	@ManyToOne
	private Question question;

}
